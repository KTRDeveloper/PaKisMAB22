// -----------------------------------------------------------------------------
// Copyright (C) 2017  Ludovic LE FRIOUX
//
// PaInleSS is free software: you can redistribute it and/or modify it under the
// terms of the GNU General Public License as published by the Free Software
// Foundation, either version 3 of the License, or (at your option) any later
// version.
//
// This program is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
// FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
// details.
//
// You should have received a copy of the GNU General Public License along with
// this program.  If not, see <http://www.gnu.org/licenses/>.
// -----------------------------------------------------------------------------

#include "painless.h"

#include "utils/Logger.h"
#include "utils/Parameters.h"
#include "utils/System.h"
#include "utils/SatUtils.h"
#include <omp.h>

#include "solvers/SolverFactory.h"

#include "clauses/ClauseManager.h"

#include "sharing/HordeSatSharing.h"
#include "sharing/SimpleSharing.h"
#include "sharing/Sharer.h"

#include "working/SequentialWorker.h"
#include "working/Portfolio.h"

#include <unistd.h>
#include <algorithm>


using namespace std;


// -------------------------------------------
// Declaration of global variables
// -------------------------------------------
atomic<bool> globalEnding(false);

Sharer ** sharers = NULL;

int nSharers = 0;

WorkingStrategy * working = NULL;

SatResult finalResult = UNKNOWN;

vector<int> finalModel;


// -------------------------------------------
// Main of the framework
// -------------------------------------------
int main(int argc, char ** argv)
{
   Parameters::init(argc, argv);

   if (Parameters::getFilename() == NULL ||
       Parameters::getBoolParam("h"))
   {
      cout << "USAGE: " << argv[0] << " [options] input.cnf" << endl;
      cout << "Options:" << endl;
      cout << "\t-c=<INT>\t\t number of cpus, default is 24" << endl;
      cout << "\t-max-memory=<INT>\t memory limit in GB, default is 51" << \
	      endl;
      cout << "\t-t=<INT>\t\t timeout in seconds, default is no limit" << endl;
//      cout << "\t-symmetry\t\t active dynamic symmetry breaking thread, "
//         "default off" << endl;
      cout << "\t-lbd-limit=<INT>\t LBD limit of exported clauses, default is" \
	      " 2" << endl;
      cout << "\t-shr-sleep=<INT>\t time in useconds a sharer sleep each " \
         "round, default is 500000 (0.5s)" << endl;
      cout << "\t-shr-lit=<INT>\t\t number of literals shared per round, " \
         "default is 1500" << endl;
      cout << "\t-v=<INT>\t\t verbosity level, default is 0" << endl;
      cout << "\t-conf-id=<INT>\t\t Specify a single configuration to use for all solvers default is -1 i.e. no single configuration" << endl;
      cout << "\t-n-sharers=<INT>\t\t Number of Sharers, default is 1" << endl;
      cout << "\t-strategy=<INT>\t\t sharing strategy, 0=SimpleSharing, 1= HordeSatSharing default is 0" << endl;
      cout << "\t-disable-export-only \t\t Allow Export only group of solvers. If used a group of solvers that do no import any clauses (they only export clauses) is not activated" << endl;

      return 0;
   }

   Parameters::printParams();

   int cpus = Parameters::getIntParam("c", 24);
   setVerbosityLevel(Parameters::getIntParam("v", 0));

//   int symmetryOn = Parameters::getBoolParam("symmetry");
   int strategy = Parameters::getIntParam("strategy", 0);
   nSharers = Parameters::getIntParam("n-sharers", 1);
   bool allowExportOnlySolvers = Parameters::getBoolParam("disable-export-only") ? false : true;
   int confId = Parameters::getIntParam("conf-id", -1);
   // Create and init solvers
   vector<SolverInterface *> solvers;

   SolverFactory::createCaDiCalSolvers(cpus, solvers);
   if (confId < 0 ) {
        SolverFactory::nativeDiversification(solvers);
   } else {
       SolverFactory::singleNativeAndRandomDiversification(solvers, confId);
   }
   
   
   loadFormulaToSolvers(solvers, Parameters::getFilename());
//   solvers[id]->loadFormula(Parameters::getFilename())
//   printf("Thread %u:iterations completed\n", omp_get_thread_num());
   int nSolvers = solvers.size();

   cout << "c " << nSolvers << " solvers are used, with IDs in [|0, "
        << nSolvers - 1 << "|]." << endl;


//   if (confId < 0 ) {
//        SolverFactory::nativeDiversification(solvers);
//   } else {
//       SolverFactory::singleNativeAndRandomDiversification(solvers, confId);
//   }


   // Init Sharing
   vector<SolverInterface *> from;
//   nSharers = nSolvers;
   sharers  = new Sharer*[nSharers];
   int nbExportOnlySolvers = min ((int)solvers.size()/2, 12);
   vector<SolverInterface *> exportOnlySolvers;
   vector<SolverInterface *> consumerSolvers;

   for (int id = 0; id < solvers.size(); id++) {
       if (allowExportOnlySolvers && id < nbExportOnlySolvers) {
            exportOnlySolvers.push_back(solvers[id]);
       } else {
            consumerSolvers.push_back(solvers[id]);
       }
   }
   
   
   
   int solversPerSharer = solvers.size() % nSharers == 0 ? solvers.size()/nSharers: solvers.size()/nSharers+1;
   cout << "c ++++++++ nSharers= " << nSharers << "/ solversPerSharer= " << solversPerSharer << endl;
   for (int i = 0; i < nSharers; i++) {
      from.clear();
      
      for (int j = i*solversPerSharer; j < min((int)solvers.size(), (i+1)*solversPerSharer); j++) {
          from.push_back(solvers[j]);
      }
      
      sharers[i] = strategy == 0 ? new Sharer(i,  new SimpleSharing(), from, consumerSolvers)
                                 : new Sharer(i,  new HordeSatSharing(), from, consumerSolvers);
   }


   // Init working
   working = new Portfolio();
   for (size_t i = 0; i < nSolvers; i++) {
      working->addSlave(new SequentialWorker(solvers[i]));
   }


   // Init the management of clauses
   ClauseManager::initClauseManager();


   // Launch working
   vector<int> cube;
   working->solve(cube);


   // Wait until end or timeout
   int timeout = Parameters::getIntParam("t", -1);

   while(globalEnding == false) {
      sleep(1);

      if (timeout > 0 && getRelativeTime() >= timeout) {
         globalEnding = true;
         working->setInterrupt();
      }
   }


   // Delete sharers
   for (int i = 0; i < nSharers; i++) {
      sharers[i]->printStats();
      delete sharers[i];
   }
   delete sharers;


   // Print solver stats
   SolverFactory::printStats(solvers);


   // Delete working strategy
   delete working;


   // Delete shared clauses
   ClauseManager::joinClauseManager();


   // Print the result and the model if SAT
   cout << "c Resolution time: " << getRelativeTime() << "s" << endl;

   if (finalResult == SAT) {
      cout << "s SATISFIABLE" << endl;

      if (Parameters::getBoolParam("no-model") == false) {
         printModel2(finalModel);
      }
   } else if (finalResult == UNSAT) {
      cout << "s UNSATISFIABLE" << endl;
   } else {
      cout << "s UNKNOWN" << endl;
   }

   return finalResult;
}
