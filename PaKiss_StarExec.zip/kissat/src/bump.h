#ifndef _bump_h_INCLUDED
#define _bump_h_INCLUDED

struct kissat;

void kissat_bump_variables (struct kissat *);

#define MAX_SCORE 1e150

#endif
