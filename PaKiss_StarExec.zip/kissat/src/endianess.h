#ifndef _endianess_h_INCLUDED
#define _endianess_h_INCLUDED

#if __BYTE_ORDER__ == __ORDER_BIG_ENDIAN__
#define KISSAT_IS_BIG_ENDIAN
#endif

#endif

